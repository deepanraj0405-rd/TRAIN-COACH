#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string coach;
    Node* next;

    Node(string c) {
        coach = c;
        next = NULL;
    }
};

class Train {
    Node* head;

public:
    Train() {
        // Already existing 4 coaches
        head = new Node("Coach1");
        head->next = new Node("Coach2");
        head->next->next = new Node("Coach3");
        head->next->next->next = new Node("Coach4");
    }

    // Add at beginning
    void addBeginning(string coach) {
        Node* newNode = new Node(coach);
        newNode->next = head;
        head = newNode;
    }

    // Add at end
    void addEnd(string coach) {
        Node* newNode = new Node(coach);

        Node* temp = head;

        while (temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    // Remove coach
    void removeCoach(string coach) {
        if (head == NULL) {
            cout << "Train is empty!\n";
            return;
        }

        // Remove first coach
        if (head->coach == coach) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << coach << " removed.\n";
            return;
        }

        Node* temp = head;

        while (temp->next != NULL &&
               temp->next->coach != coach) {
            temp = temp->next;
        }

        if (temp->next == NULL) {
            cout << coach << " not found.\n";
            return;
        }

        Node* deleteNode = temp->next;
        temp->next = deleteNode->next;
        delete deleteNode;

        cout << coach << " removed.\n";
    }

    // Display
    void display() {
        Node* temp = head;

        cout << "Train: ";

        while (temp != NULL) {
            cout << temp->coach;

            if (temp->next != NULL)
                cout << " -> ";

            temp = temp->next;
        }

        cout << " -> NULL\n";
    }
};

int main() {
    Train train;
    int choice;
    string coach;

    do {
        cout << "\n===== TRAIN MENU =====\n";
        cout << "1. Add Coach at Beginning\n";
        cout << "2. Add Coach at End\n";
        cout << "3. Remove Coach\n";
        cout << "4. Display Coaches\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            cout << "Enter coach name: ";
            cin >> coach;
            train.addBeginning(coach);
            break;

        case 2:
            cout << "Enter coach name: ";
            cin >> coach;
            train.addEnd(coach);
            break;

        case 3:
            cout << "Enter coach name to remove: ";
            cin >> coach;
            train.removeCoach(coach);
            break;

        case 4:
            train.display();
            break;

        case 5:
            cout << "Program ended.\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 5);

    return 0;
}
